// Typing Animation
var typed=new Typed(".typing",{
    strings:["","Python Developer","Data Analyst","Data Scientist","Machine Learning Engineer"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})